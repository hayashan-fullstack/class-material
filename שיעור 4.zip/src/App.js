import React from 'react'
import Note from './components/Note'
//import  { useState } from 'react'

const App = ({ notes }) => {

  //const [notes, setNotes] = useState(notes)
  // const [newNote, setNewNote] = useState( 'a new note...') 
  //const [showAll, setShowAll] = useState(true)
  // const notesToShow = showAll
  //   ? notes
  //   : notes.filter(note => note.important === true)
  const rows = () => notes.map(note =>
    <Note
      key={note.id}
      note={note}
    />
  )
  // const addNote = (event) => {
  //   event.preventDefault()
  //   console.log('button clicked', event.target)
  // }

  // const handleNoteChange = (event) => {
  //   console.log(event.target.value)
  //   setNewNote(event.target.value)
  // }

  // const noteObject = {
  //   content: newNote,
  //   date: new Date().toISOString(),
  //   important: Math.random() > 0.5,
  //   id: notes.length + 1,
  // }
  
  return (
    <div>
      <h1>Notes</h1>
      
      <ul>
        {rows()}
      </ul>
    </div>
  )
}

export default App


{/* <div>
        <button onClick={() => setShowAll(!showAll)}>
          show {showAll ? 'important' : 'all' }
        </button>
      </div> */}

      {/* <form onSubmit={addNote}>
        <input />
        <button type="submit">save</button>
      </form>    */}
