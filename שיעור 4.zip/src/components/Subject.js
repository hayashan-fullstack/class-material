import React from 'react'
import Note from './Note'

const Subject = ({ subject }) => {
    const rows = () => subject.notes.map(note =>
        <Note
          key={note.id}
          note={note}
        />
      )
  return (
    <div>
    <h1>{subject.subject}</h1>
    <ul>
      {rows()}
    </ul>
  </div>
  )
}
export default Subject