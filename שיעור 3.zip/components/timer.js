import React, { useState, useRef } from "react";

const Line = ({ line }) => {
    return (<div>
        <li>{line}</li>
    </div>)
}

export const Timer = () => {
    const [seconds, setSeconds] = useState(0)
    const [minutes, setMinutes] = useState(0)
    const [history, setHistory] = useState([])
    const timerRef = useRef(null)
    const restartTimer = () => {
        setHistory(history.concat('' + minutes + ':' + seconds))
        if (timerRef.current !== null) {
            clearTimeout(timerRef.current);
        }

        setSeconds(0)
        setMinutes(0)
    }
    timerRef.current = setTimeout(() => {
        if (seconds === 59) {
            setSeconds(0)
            setMinutes(minutes + 1)
        }
        else {
            setSeconds(seconds + 1)
        }
    }, 100)
    return (<div>
        <h1>Timer: </h1>
        <h2>{minutes > 9 ? minutes : '0' + minutes}:{seconds > 9 ? seconds : '0' + seconds}</h2>
        <button onClick={restartTimer}>restart</button>
        <ul>
            {history.map((line, i) => <Line line={line} key={i} />)}
        </ul>

    </div>)
}